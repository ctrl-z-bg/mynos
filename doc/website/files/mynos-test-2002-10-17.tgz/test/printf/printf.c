#include "stdarg.h"
#include "_printf.h"
#include "../../kernel/global.h"

extern ssize_t write(int fd, const void *buf, size_t count);

static int _print_char(unsigned c, void **helper) {
  write(0, &c, 1);
}

static int _add_char(unsigned c, void **helper) {
  *(char*)((*helper)++) = c;
  *(char*)(*helper) = '\0';
}



int printf(const char *format, ...) {
  int n;
  char tmp[100];

  va_list arg_ptr;
  va_start(arg_ptr, format);
  n=do_printf(format, arg_ptr, _add_char, tmp);
  va_end(arg_ptr);
  write(0, tmp, strlen(tmp));
  return n;
}
