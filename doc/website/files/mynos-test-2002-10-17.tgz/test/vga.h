#ifndef _KERNEL_VGA_H_
#define _KERNEL_VGA_H_

int init_graph_vga(int width, int height,int chain4);
void vga_put_pixel(unsigned short x, unsigned short y, char color);
void vga_draw_line(unsigned short x1, unsigned short y1, 
		   unsigned short x2, 
		   unsigned short y2, char color);
void vga_draw_polygon(int num_vertices, int *vertices, char color);
void vga_draw_rect(int left,int top, int right, int bottom, char color);
void vga_draw_rect_fill(int left,int top, int right, int bottom, char color);

/*
0 Black
1 Blue
2 Green
3 Cyan
4 Red
5 Magenta
6 Brown
7 Light Gray
8 Dark Gray 
9 Light Blue
10 Light Green
11 Light Cyan
12 Light Red
13 Light Magenta
14 Yellow
15 White
*/
#endif
