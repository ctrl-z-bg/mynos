#!/usr/bin/perl

print << "EndOfSection";
# Entry 0:
title   Mynos
root    (fd1)
kernel /kernel.elf
EndOfSection

while(<>) {
    chomp;
    if (!(/^\#/)) {
	print "module /$_\n";
    }
}
