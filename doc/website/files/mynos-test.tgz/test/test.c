#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <elf.h>
#include <mynos.h>

#include "vga.h"


#if 1
int main() {
    int i;
    int a = 0;
    int ret;

  if (fork()) {
    int pid;
    char asd[20];
    strcat(asd, "messaggio");
    for (i = 0; i < 350000; i++) a++;
    ret = mynos_recvAll(&pid, asd, 20, 0);
    printf("ricevuto %s da %d (%d byte)\n", asd, pid, ret);
  } else {
    int a = 5;
    char * msg = "CIAO";
    printf("figlio creato\n");
    ret = mynos_send(1, msg, (strlen(msg)+1), MYNOS_IPC_FLAGS_NONBLOCK);
    printf("spedito messaggio lungo %d\n", ret);
  }    
  return 1;
}

#else

int main() {
  int radice = (int)sqrt(9);
  int i, y;
  int * mypid;
  int child;

  mypid = (int*)malloc(sizeof(int));
  if ((child = fork()) == 0) {
    fork();
    mypid = (int*)malloc(sizeof(int));
    *mypid = getpid();
#if 0
    if (getpid() == 2) {
      for (y = 0; y < 200; y++) {
	vga_draw_line(0, y, 319, y, 0);
      }
      vga_draw_rect(0,0,319,199, 15);
      
      vga_draw_rect_fill(50, 20, 80, 50, 15);
      vga_draw_rect_fill(100, 20, 130, 50, 15);
      vga_draw_line(90, 50, 90, 150, 15);
      vga_draw_line(60, 170, 120, 170, 15);
      vga_draw_line(50, 160, 60, 170, 15);
      vga_draw_line(120, 170, 130, 160, 15);
    }
#endif
    while(1) {
      printf("process %d (with father %d): sqrt(9)=%d\n" , *mypid, getppid(), 
	     radice);
    }
  } else {
    mypid = (int*)malloc(sizeof(int));
    *mypid = getpid();
    while(1) {
      printf("process %d (child = %d): sqrt(9)=%d\n" , *mypid, child, radice);
    }
  }
  
  return 1;
}

#endif
