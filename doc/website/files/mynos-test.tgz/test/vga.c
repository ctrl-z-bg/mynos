#include "vga.h"

typedef char byte;
typedef unsigned short word;
typedef unsigned long dword;

typedef char           byte_t;
typedef unsigned int   uint32_t;
typedef int            int32_t;
typedef unsigned long  ulong32_t;
typedef long           long32_t;
typedef unsigned short ushort16_t;
typedef short          short16_t;

unsigned char *VGA = (unsigned char*)0xA0000;     

#define SZ(x) (sizeof(x)/sizeof(x[0]))


void vga_put_pixel(unsigned short x, unsigned short y, unsigned char color) {
  ushort16_t offset;

  offset = (y<<8) + (y<<6) + x;
  VGA[offset] = color;
}

unsigned char vga_get_pixel(unsigned short x, unsigned short y) {
  ushort16_t offset;

  offset = (y<<8) + (y<<6) + x;
  return VGA[offset];
}

/**************************************************************************
 *    draws a line using Bresenham's line-drawing algorithm, which uses   *
 *    no multiplication or division.                                      *
 **************************************************************************/

#define abs(X) ((X>=0)?X:-X)
#define sgn(x) ((x<0)?-1:((x>0)?1:0)) /* macro to return the sign of a
                                         number */
void vga_draw_line(unsigned short x1, unsigned short y1, 
		   unsigned short x2, 
		   unsigned short y2, unsigned char color)
{
  short16_t i,dx,dy,sdx,sdy,dxabs,dyabs,x,y,px,py;

  dx=x2-x1;      /* the horizontal distance of the line */
  dy=y2-y1;      /* the vertical distance of the line */
  dxabs=abs(dx);
  dyabs=abs(dy);
  sdx=sgn(dx);
  sdy=sgn(dy);
  x=dyabs>>1;
  y=dxabs>>1;
  px=x1;
  py=y1;

  VGA[(py<<8)+(py<<6)+px]=color;

  if (dxabs>=dyabs) /* the line is more horizontal than vertical */
  {
    for(i=0;i<dxabs;i++)
    {
      y+=dyabs;
      if (y>=dxabs)
      {
        y-=dxabs;
        py+=sdy;
      }
      px+=sdx;
      vga_put_pixel(px,py,color);
    }
  }
  else /* the line is more vertical than horizontal */
  {
    for(i=0;i<dyabs;i++)
    {
      x+=dxabs;
      if (x>=dyabs)
      {
        x-=dyabs;
        px+=sdx;
      }
      py+=sdy;
      vga_put_pixel(px,py,color);
    }
  }
}

void vga_draw_polygon(int num_vertices, 
		      int *vertices,
		      unsigned char color) 
{
  int i;

  for(i=0;i<num_vertices-1;i++)
  {
    vga_draw_line(vertices[(i<<1)+0],
		  vertices[(i<<1)+1],
		  vertices[(i<<1)+2],
		  vertices[(i<<1)+3],
		  color);
  }
  vga_draw_line(vertices[0],
		vertices[1],
		vertices[(num_vertices<<1)-2],
		vertices[(num_vertices<<1)-1],
		color);
}

#define SCREEN_WIDTH        320       /* width in pixels of mode 0x13 */
#define SCREEN_HEIGHT       200       /* height in pixels of mode 0x13 */
void vga_draw_rect(int left,int top, int right, int bottom, 
		   unsigned char color)
{
  word top_offset,bottom_offset,i,temp;

  if (top>bottom)
  {
    temp=top;
    top=bottom;
    bottom=temp;
  }
  if (left>right)
  {
    temp=left;
    left=right;
    right=temp;
  }

  top_offset=(top<<8)+(top<<6);
  bottom_offset=(bottom<<8)+(bottom<<6);

  for(i=left;i<=right;i++)
  {
    VGA[top_offset+i]=color;
    VGA[bottom_offset+i]=color;
  }
  for(i=top_offset;i<=bottom_offset;i+=SCREEN_WIDTH)
  {
    VGA[left+i]=color;
    VGA[right+i]=color;
  }
}

void vga_draw_rect_fill(int left,int top, int right, int bottom, 
			unsigned char color)
{
  word top_offset,bottom_offset,i,temp,width;

  if (top>bottom)
  {
    temp=top;
    top=bottom;
    bottom=temp;
  }
  if (left>right)
  {
    temp=left;
    left=right;
    right=temp;
  }

  top_offset=(top<<8)+(top<<6)+left;
  bottom_offset=(bottom<<8)+(bottom<<6)+left;
  width=right-left+1;

  for(i=top_offset;i<=bottom_offset;i+=SCREEN_WIDTH)
  {
    memset(&VGA[i],color,width);
  }
}

